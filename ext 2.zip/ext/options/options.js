$(document).ready(function() {

  // $('#options').on('click', function(){
  //   window.location.path = 'options.html#/general'
  // });

  // $('#themes').on('click', function(){
  //   window.location.path = 'options.html#/general'

  // });

  // $('#blacklist').on('click', function(){

  // });
})